import json
import boto3
import botocore
import os
import subprocess
import shlex
import glob
import urllib.parse
import re
import time

s3 = boto3.resource('s3')
s3_client = boto3.client('s3')
fragment_duration = os.environ['FRAGMENT_DURATION']
output_bucket = os.environ['BUCKET']
output_bucket_prefix = os.environ['OUTPUT_S3_PREFIX']

def num_sort(file_path):
    return list(map(int, re.findall(r'\d+', file_path.split('.')[0])))[-1]

def lambda_handler(event, context):
    # Get video and bucket data
    input_bucket = event['Records'][0]['s3']['bucket']['name']
    input_key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    video_name = input_key.split('/')[-1]
    
    if(video_name == ''):
        return
    
    print('Bucket: {} -- Key: {} -- Video: {}'.format(input_bucket, input_key, video_name))
    
    # Download video into lambda memory
    raw_videos_path = '/tmp/raw_videos'
    os.makedirs(raw_videos_path, exist_ok=True)

    s3.Bucket(input_bucket).download_file(input_key, '{}/{}'.format(raw_videos_path,video_name))
    tmp_file_path='{}/{}'.format(raw_videos_path,video_name)
    
    # Cut video in fragments
    command = "/opt/bin/ffmpeg -i {} -acodec copy -f segment -segment_time {} -vcodec copy -reset_timestamps 1 -map 0 /tmp/{}_%d.mp4".format(tmp_file_path, fragment_duration, video_name.rsplit('.',1)[0])
    command1 = shlex.split(command)
    subprocess.run(command1)
    
    # Upload fragments to s3 bucket
    generated_fragments = glob.glob("/tmp/*.mp4")
    generated_fragments.sort(key=num_sort)
    print('Generated fragments: {}'.format(generated_fragments)) 

    for fragment in generated_fragments:
        fragment_name = fragment.split('/').pop()
        response = s3_client.upload_file(fragment, output_bucket, '{}{}/{}'.format(output_bucket_prefix,video_name.rsplit('.',1)[0], fragment_name))
        time.sleep(4)
        os.remove(fragment) 
        
    os.remove(tmp_file_path) 
    
    return {
        'statusCode': 200,
        'body': json.dumps("The video {} has been successfully cut. Fragments: {} - Fragments duration: {}".format(video_name, len(generated_fragments),fragment_duration))
    }

    

