import os
import json

def build_payload(bucket, key, video_name):
    f = open('payload.json')
    payload = dict()
    payload["videos"] = []
        
    area = video_name.split("area_")
    if len(area) > 1:
        area = area[-1].split("_")[0]
    else:
        area = "default"

    video_areas = os.environ.get("AREAS", [])
    
    
    video_areas = video_areas.replace("\'", "\"")

    payload["cameras"] = json.loads(video_areas)
    payload['refresh_threshold'] = float(os.environ.get('REFRESH_THRESHOLD', "120")) #2min 
    payload['division_area'] = float(os.environ.get('DIVISION_AREA', "600"))
    payload['tracking_threshold'] = float(os.environ.get('TRACKING_THRESHOLD', "70"))
    payload['detection_threshold'] = float(os.environ.get('DETECTION_THRESHOLD', "60"))
    payload["frame_rate"] = float(os.environ.get('FRAME_RATE', 3))
    payload["videos"].append({'path': 's3://' + bucket + '/' + key, 'area': area})

    return payload